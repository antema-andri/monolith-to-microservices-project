# enpoint frontend
http://af325ef8cf17149e39133d87cbd49c8b-576690033.us-east-2.elb.amazonaws.com
# endpoint backend
http://a0a39883cda5a47bdafa273df6bf0829-1715069648.us-east-2.elb.amazonaws.com:8080/api/v0